import React, { useState } from "react";
import "./Comment.css";
import moment from "moment";
const DisplayComment = ({
  cid,
  commentbody,
  userid,
  commenton,
  usercommented,
}) => {
  const [edit, setedit] = useState(false);
  const [cmtbody, setcommentbody] = useState("");
  const [cmtid, setcmtid] = useState("");
  const currentuser = {
    result: {
      email: "abcd@gmail.com",
      joinedon: "222-07-134",
    },
  };
  const handleedit = (ctid, ctbody) => {
    setedit(true);
    setcmtid(ctid);
    setcommentbody(ctbody);
  };
  return (
    <>
      {edit ? (
        <>
          <form className="comments_sub_form_comments">
            <input
              type="text"
              onChange={(e) => setcommentbody(e.target.value)}
              placeholder="Edit comments.."
              value={cmtbody}
              className="comment_ibox"
            />
            <input
              type="submit"
              value="Change"
              className="comment_add_btn_comments"
            />
          </form>
        </>
      ) : (
        <p className="comment_body">{commentbody}</p>
      )}
      <p className="usercommented">
        {" "}
        - {usercommented} commented {moment(commenton).fromNow()}
      </p>
      {currentuser?.result?._id === userid && (
        <p className="EditDel_DisplayCommendt">
          <i onClick={() => handleedit(cid, commentbody)}>Edit</i>
          <i>Delete</i>
        </p>
      )}
    </>
  );
};

export default DisplayComment;
