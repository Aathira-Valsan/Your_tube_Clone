import React, { useState } from "react";
import "./Comment.css";
import DisplayComment from "./DisplayComment";

const Comment = ({ videoid }) => {
  const [commenttext, setcommenttext] = useState("");
  const currentuser = 1;
  const commentlist = [
    {
      _id: 1,
      commentbody: "hello",
      usercommented: "Abc",
    },
    {
      _id: 2,
      commentbody: "hello",
      usercommented: "Abc",
    },
  ];
  const handleonsubmit = (e) => {
    e.preventDefault();
    if (currentuser) {
      if (!commenttext) {
        alert("Please type your comment!!");
      } else {
        alert("Please login to add comment!!");
      }
    }
  };
  return (
    <>
      <form className="comments_sub_form_comments" onSubmit={handleonsubmit}>
        <input
          type="text"
          onChange={(e) => setcommenttext(e.target.value)}
          placeholder="add comment..."
          value={commenttext}
          className="comment_ibox"
        />
        <input type="submit" value="add" className="comment_add_btn_comments" />
      </form>
      <div className="display_comment_container">
        {commentlist
          ?.filter((q) => videoid === q?._id)
          .reverse()
          .map((m) => {
            return (
              <DisplayComment
                cid={m._id}
                userid={m.userid}
                commentbody={m.commentbody}
                commenton={m.commenton}
                usercommented={m.usercommented}
              />
            );
          })}
      </div>
    </>
  );
};

export default Comment;
